from flask import Flask, request, make_response
app = Flask(__name__)
@app.route('/')
def i():
    return '''
<h1>來這裡幹嘛?回去吧，只是個無聊網站而已</h1>
<a href="/h">h</a>


'''
app.run('0.0.0.0', 6067, True)