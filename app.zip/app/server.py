import threading
from flask import Flask, request, make_response
from model.BCSFE_Python import __main__
from model.BCSFE_Python.server_handler import get_b
from model.BCSFE_Python.user_input_handler import get_i
from model.BCSFE_Python.helper import sleep
import time
err=None
first_re=True
app = Flask(__name__)

def run(key, code, version):
    global err
    try:
        __main__.normal_start_up(key, code, version)
    except Exception as errrr:
        print('我出錯了')
        get_i().process_done=True
        
        err=errrr

        
@app.route('/h')
def h():
    global err,first_re
    key = request.args.get('key')
    code = request.args.get('code')
    print(f'數量:{threading.active_count()}')
    
    if not all([key, code]):
        return make_response('''<h1>APIERROR</h1>
            [info]: key or code is None''', 400, {'Cache-Control': 'no-store'})

    try:
        
        get_i().set_value(0)
        get_i().have_requests=True
        get_i().process_done=False
        count=0
        if threading.active_count()<=3:
                         
            threading.Thread(target=__main__.normal_start_up,args=(key, code, '14.0')).start()
            
        
    except Exception as err:
        return make_response(f"<h1>APIERROR</h1><p>[info]: {err}</p>", 500)

    while not get_i().process_done:
        sleep()
        print('我在睡覺')
        count+=1
        if count>5:
            get_i().process_done=True
            print('強制中止')
    if not err is None:
        return make_response(f"<h1>APIERROR</h1><p>[info]: {err}</p>", 500)

    response = get_b()
    return make_response(response, 200, {'Cache-Control': 'no-store'})



@app.route('/')
def i():
    return '''
<h1>來這裡幹嘛?回去吧，只是個無聊網站而已</h1>
<a href="/h">h</a>


'''
app.run('0.0.0.0', 6067, True)



