from flask import Flask
from flask import request
from model.BCSFE_Python import __main__
from model.BCSFE_Python.server_handler import get_b

app=Flask(__name__)
@app.route('/h')
def h():
    key=request.args.get('key')
    code=request.args.get('code')
    
    try:
        if not all([key,code]):
            return '''<h1>APIERROR</h1>
            [info]:key or code is None'''
        
        __main__.normal_start_up(key,code,'14.0')
        
    except Exception as err:
        
        if type(err) == TypeError:
            return '''<h1>APIERROR</h1>
                    [info]:key or code is incorrect'''
        return get_b()
    
    
app.run('0.0.0.0',6067)