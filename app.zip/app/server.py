import threading
from flask import Flask, request, make_response
from model.BCSFE_Python import __main__
from model.BCSFE_Python.server_handler import get_b
from model.BCSFE_Python.user_input_handler import reset_inputidx
processing=False
app = Flask(__name__)

def run_normal_start_up(key, code, event):
    global processing
    processing=True
    try:
        __main__.normal_start_up(key, code, '14.0')
    except Exception as err:
        print(f"Error in normal_start_up: {err}")
        reset_inputidx()

    finally:
        event.set() 
        processing =False
        #完成標

from flask import Flask, request, make_response
from model.BCSFE_Python import __main__
from model.BCSFE_Python.server_handler import get_b

app = Flask(__name__)

@app.route('/h')
def h():
    key = request.args.get('key')
    code = request.args.get('code')

    if not all([key, code]):
        return make_response('''<h1>APIERROR</h1>
            [info]: key or code is None''', 400, {'Cache-Control': 'no-store'})

    try:
        
        __main__.normal_start_up(key, code, '14.0')
    except Exception as err:
        print(f"Error in normal_start_up: {err}")
        reset_inputidx()
        if str(err)=='':
            return get_b()
        return make_response(f"<h1>APIERROR</h1><p>[info]: {err}</p>", 500)

    
    response = get_b()
    return make_response(response, 200, {'Cache-Control': 'no-store'})

app.run('0.0.0.0', 6067, debug=True)

@app.route('/')
def i():
    return '''
<h1>來這裡幹嘛?回去吧，只是個無聊網站而已</h1>
<a href="/h">h</a>


'''
app.run('0.0.0.0', 6067, debug=True)


